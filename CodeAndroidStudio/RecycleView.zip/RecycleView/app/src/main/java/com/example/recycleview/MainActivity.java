package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    ApiService apiService;
    private RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<PriceCoin> priceCoinList = new ArrayList<>();
        List<String> tokenList = new ArrayList<>();
        List<Double> priceList = new ArrayList<>();
        apiService = RetrofitClient.getApiService();

        Call<MarketData> call = apiService.getMarketData();
        call.enqueue(new Callback<MarketData>() {
            @Override
            public void onResponse(Call<MarketData> call, Response<MarketData> response) {
                if (response.isSuccessful()) {
                    MarketData marketData = response.body();
                    for (int i = 0; i < marketData.getPriceCoin().size(); i++) {
                        tokenList.add(marketData.getPriceCoin().get(i).getToken());
                        priceList.add(marketData.getPriceCoin().get(i).getPrice());
                    }
                    if (marketData.getPriceCoin() != null) {
                        Toast.makeText(MainActivity.this, tokenList.get(1), Toast.LENGTH_SHORT).show();

                        List<PriceCoin> priceCoinList = new ArrayList<>();
                        for (int i = 0; i < tokenList.size(); i++) {
                            priceCoinList.add(new PriceCoin(tokenList.get(i), priceList.get(i), R.drawable.img));
                        }

                        recyclerView = findViewById(R.id.recyclerView);
                        MyAdapter myAdapter = new MyAdapter(priceCoinList);
                        recyclerView.setAdapter(myAdapter);
                        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 1));
                    }
                } else {
                    // Xử lý lỗi
                    Toast.makeText(MainActivity.this, "Error: " + response.message(), Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onFailure(Call<MarketData> call, Throwable t) {
                // Xử lý khi yêu cầu thất bại
                Toast.makeText(MainActivity.this, "Failure: " + t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }
}