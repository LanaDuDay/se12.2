package com.example.recycleview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Handler;
import android.os.Bundle;
import java.io.File;
import java.io.IOException;

import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Looper;
import java.util.ArrayList;
import java.util.List;
import android.widget.ImageView;
import android.content.Intent;

import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    ApiService apiService;
    private RecyclerView recyclerView;
    private Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        ImageView imageViewButton1 = findViewById(R.id.imageViewButton1);
        imageViewButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 1
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        // ImageView cho Button 2
        ImageView imageViewButton2 = findViewById(R.id.imageViewButton2);
        imageViewButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 2
                Intent intent = new Intent(MainActivity.this, MainActivity.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        ImageView imageViewButton3 = findViewById(R.id.imageViewButton3);
        imageViewButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 2
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        ImageView imageViewButton4 = findViewById(R.id.imageViewButton4);
        imageViewButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 2
                Intent intent = new Intent(MainActivity.this, MainActivity4.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        handler = new Handler(Looper.getMainLooper());
        fetchDataAndUpdateUI();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchDataAndUpdateUI();
                handler.postDelayed(this, 60000); // 1 phút = 60,000 milliseconds
            }
        }, 60000);
    }
    private void fetchDataAndUpdateUI() {
        List<PriceCoin> priceCoinList = new ArrayList<>();
        List<String> symbolList = new ArrayList<>();
        List<Double> priceList = new ArrayList<>();
        List<Double> quantityList = new ArrayList<>();
        apiService = RetrofitClient.getApiService();

        Call<MarketData> call = apiService.getMarketData();
        call.enqueue(new Callback<MarketData>() {
            @Override
            public void onResponse(Call<MarketData> call, Response<MarketData> response) {
                if (response.isSuccessful()) {
                    MarketData marketData = response.body();
                    for (int i = 0; i < marketData.getPriceCoin().size(); i++) {
                        symbolList.add(marketData.getPriceCoin().get(i).getSymbol());
                        priceList.add(marketData.getPriceCoin().get(i).getPrice());
                        quantityList.add(marketData.getPriceCoin().get(i).getQuantity());

                    }
                    if (marketData.getPriceCoin() != null) {
                        Toast.makeText(MainActivity.this, String.valueOf(symbolList.size()), Toast.LENGTH_SHORT).show();

                        List<PriceCoin> priceCoinList = new ArrayList<>();
                        for (int i = 0; i < symbolList.size(); i++) {
                            priceCoinList.add(new PriceCoin(symbolList.get(i), priceList.get(i), R.drawable.img, quantityList.get(i)));
                        }

                        recyclerView = findViewById(R.id.recyclerView2);
                        MyAdapter myAdapter = new MyAdapter(priceCoinList);
                        myAdapter.setItemClickListener(new MyAdapter.OnMyItemClickListener() {
                            @Override
                            public void doSomeThing(int position) {
                                try {
                                    OkHttpClient okHttpClient = new OkHttpClient();

                                    // Tạo dữ liệu form
                                    RequestBody formBody = new FormBody.Builder()
                                            .add("symbol", priceCoinList.get(position).getCoinName())
                                            .build();

                                    // Tạo request POST
                                    Request request = new Request.Builder()
                                            .url("http://192.168.1.9:5000/order_book")
                                            .post(formBody)
                                            .build();
                                    okHttpClient.newCall(request).enqueue(new okhttp3.Callback() {
                                        @Override
                                        public void onFailure(@NonNull okhttp3.Call call, @NonNull IOException e) {
                                            MainActivity.this.runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                                }
                                            });
                                        }

                                        @Override
                                        public void onResponse(@NonNull okhttp3.Call call, @NonNull okhttp3.Response response) throws IOException {
                                            if (response.isSuccessful()) {
                                                MainActivity.this.runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        
                                                        ResponseBody orderBook = response.body();
                                                        Toast.makeText(MainActivity.this, String.valueOf(orderBook), Toast.LENGTH_SHORT).show();
                                                    }
                                                });

                                            } else {
                                                MainActivity.this.runOnUiThread(new Runnable() {
                                                    @Override
                                                    public void run() {
                                                        Toast.makeText(MainActivity.this, "Không thành công", Toast.LENGTH_SHORT).show();
                                                    }
                                                });
                                            }
                                        }
                                    });

                                } catch (Exception e) {
                                    // Xử lý khi có lỗi xảy ra
                                    Toast.makeText(MainActivity.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }//dosomethingend
                        });
                        recyclerView.setAdapter(myAdapter);
                        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 1));
                    }
                } else {
                    // Xử lý lỗi
                    Toast.makeText(MainActivity.this, "Error: " + response.message(), Toast.LENGTH_SHORT).show();

                }

            }

            @Override
            public void onFailure(Call<MarketData> call, Throwable t) {
                // Xử lý khi yêu cầu thất bại
                Toast.makeText(MainActivity.this, "Failure: " + t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    protected void onDestroy() {
        // Hủy bỏ lặp lại khi Activity bị hủy
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }


}