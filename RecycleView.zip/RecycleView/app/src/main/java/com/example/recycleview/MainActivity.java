package com.example.recycleview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Handler;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Looper;
import java.util.ArrayList;
import java.util.List;
import android.widget.ImageView;
import android.content.Intent;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class MainActivity extends AppCompatActivity {
    TextView textView;
    ApiService apiService;
    private RecyclerView recyclerView;
    private Handler handler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imageViewButton1 = findViewById(R.id.imageViewButton1);
        imageViewButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 1
                Intent intent = new Intent(MainActivity.this, MainActivity3.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        // ImageView cho Button 2
        ImageView imageViewButton2 = findViewById(R.id.imageViewButton2);
        imageViewButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 2
                Intent intent = new Intent(MainActivity.this, MainActivity.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        ImageView imageViewButton3 = findViewById(R.id.imageViewButton3);
        imageViewButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 2
                Intent intent = new Intent(MainActivity.this, MainActivity2.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        ImageView imageViewButton4 = findViewById(R.id.imageViewButton4);
        imageViewButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Định nghĩa Intent cho Activity 2
                Intent intent = new Intent(MainActivity.this, MainActivity4.class);

                // Chạy Intent
                startActivity(intent);
            }
        });

        handler = new Handler(Looper.getMainLooper());
        fetchDataAndUpdateUI();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                fetchDataAndUpdateUI();
                handler.postDelayed(this, 60000); // 1 phút = 60,000 milliseconds
            }
        }, 60000);
    }
    private void fetchDataAndUpdateUI() {
        List<PriceCoin> priceCoinList = new ArrayList<>();
        List<String> tokenList = new ArrayList<>();
        List<Double> priceList = new ArrayList<>();
        apiService = RetrofitClient.getApiService();

        Call<MarketData> call = apiService.getMarketData();
        call.enqueue(new Callback<MarketData>() {
            @Override
            public void onResponse(Call<MarketData> call, Response<MarketData> response) {
                if (response.isSuccessful()) {
                    MarketData marketData = response.body();
                    for (int i = 0; i < marketData.getPriceCoin().size(); i++) {
                        tokenList.add(marketData.getPriceCoin().get(i).getToken());
                        priceList.add(marketData.getPriceCoin().get(i).getPrice());
                    }
                    if (marketData.getPriceCoin() != null) {
                        Toast.makeText(MainActivity.this, tokenList.get(1), Toast.LENGTH_SHORT).show();

                        List<PriceCoin> priceCoinList = new ArrayList<>();
                        for (int i = 0; i < tokenList.size(); i++) {
                            priceCoinList.add(new PriceCoin(tokenList.get(i), priceList.get(i), R.drawable.img));
                        }

                        recyclerView = findViewById(R.id.recyclerView2);
                        MyAdapter myAdapter = new MyAdapter(priceCoinList);
                        recyclerView.setAdapter(myAdapter);
                        recyclerView.setLayoutManager(new GridLayoutManager(MainActivity.this, 1));
                    }
                } else {
                    // Xử lý lỗi
                    Toast.makeText(MainActivity.this, "Error: " + response.message(), Toast.LENGTH_SHORT).show();

                }

            }

            @Override
            public void onFailure(Call<MarketData> call, Throwable t) {
                // Xử lý khi yêu cầu thất bại
                Toast.makeText(MainActivity.this, "Failure: " + t.getMessage(), Toast.LENGTH_SHORT).show();

            }
        });
    }

    @Override
    protected void onDestroy() {
        // Hủy bỏ lặp lại khi Activity bị hủy
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        super.onDestroy();
    }
}