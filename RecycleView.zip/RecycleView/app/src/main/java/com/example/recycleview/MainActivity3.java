package com.example.recycleview;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        Button btnOpenPopup = findViewById(R.id.button);
        btnOpenPopup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Tạo Dialog
                final Dialog dialog = new Dialog(MainActivity3.this);

                // Set layout cho Dialog
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.popup_layout);

                // Các xử lý khác nếu cần

                // Hiển thị Dialog
                dialog.show();

                // Xử lý sự kiện khi nhấn nút "Close"
                Button btnClosePopup = dialog.findViewById(R.id.btnClosePopup);
                btnClosePopup.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Đóng Dialog khi nhấn nút "Close"
                        dialog.dismiss();
                    }
                });

                // Xử lý sự kiện khi nhấn nút "Trade"
                Button btnTrade = dialog.findViewById(R.id.btnTrade);
                btnTrade.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // Kiểm tra xem cả hai EditText đã được điền đầy đủ hay không
                        EditText edtQuantity = dialog.findViewById(R.id.edtQuantity);
                        EditText edtTransactionType = dialog.findViewById(R.id.edtTransactionType);

                        String quantity = edtQuantity.getText().toString();
                        String transactionType = edtTransactionType.getText().toString();

                        if (!quantity.isEmpty() && !transactionType.isEmpty()) {
                            // Cả hai EditText đã được điền đầy đủ
                            Toast.makeText(MainActivity3.this, "Đã điền đầy đủ", Toast.LENGTH_SHORT).show();
                        } else {
                            // Có ít nhất một EditText chưa được điền đầy đủ
                            Toast.makeText(MainActivity3.this, "Vui lòng điền đầy đủ thông tin", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });
    }
}
