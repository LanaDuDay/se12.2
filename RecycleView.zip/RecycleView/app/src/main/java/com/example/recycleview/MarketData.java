package com.example.recycleview;


import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MarketData {
    @SerializedName("PriceCoin")
    private List<PriceCoin> priceCoin;

    public List<PriceCoin> getPriceCoin() {
        return priceCoin;
    }

    public void setPriceCoin(List<PriceCoin> priceCoin) {
        this.priceCoin = priceCoin;
    }

    public static class PriceCoin {
        @SerializedName("token")
        private String token;

        @SerializedName("price")
        private double price;

        public String getToken() {
            return token;
        }

        public void setToken(String token) {
            this.token = token;
        }

        public double getPrice() {
            return price;
        }

        public void setPrice(double price) {
            this.price = price;
        }
    }
}
